﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swin_ADV
{
    public class Item : Game_Object
    {
        public Item(string[] idents, string name, string desc) : base(idents, name, desc)
        {

        }


    }
}
