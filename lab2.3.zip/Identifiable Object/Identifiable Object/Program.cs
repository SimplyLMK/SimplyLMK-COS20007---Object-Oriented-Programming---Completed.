﻿using System;

namespace Identifiable_Object;

public class Program
{
    public static void Main(string[] args)
    {
      
        string[] identifiers = new string[] { "kha", "fren", "something" };
        string[] empty = new string[] { };

        Identifiable identifiable = new Identifiable(identifiers);
        Identifiable empty_object = new Identifiable(empty);

        Console.WriteLine($"testing for AreYou: {identifiable.AreYou("kha")}");
        Console.WriteLine($"testing for Not AreYou: {identifiable.AreYou("big black cockroaches")}"); 

        Console.WriteLine($"Testing for case sensitivity AreYou: {identifiable.AreYou("KHA")}");
        Console.WriteLine($"Testing for case sensitivity Not AreYou: {identifiable.AreYou("Fren")}"); 

        Console.WriteLine($"Testing first ID: {identifiable.FirstId}");
        Console.WriteLine($"Testing an empty first ID: {empty_object.FirstId}");

        identifiable.AddIdentifier("newly added first id");
        identifiable.AddIdentifier("kha");

        Console.WriteLine($"{identifiable.AreYou("newly added first id")}"); 
        Console.WriteLine(identifiable.FirstId); 
    }
}