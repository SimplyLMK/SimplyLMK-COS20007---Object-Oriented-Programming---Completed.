



namespace Clock
{
    public class Tests
    {
        private Counter _counter;

        [SetUp]
        public void Setup()
        {
            _counter = new Counter("Test counter");
        }

        [Test]
  
        public void TestName()
        {
            Assert.AreEqual("Test counter", _counter.Name);
        }

        [TestCase(60, 60)]
        [TestCase(100, 100)]

        [Test]
        public void TestIncrement(int tick, int result)
        {

            int i;
            for (i = 0; i < tick; i++)
            {
                _counter.Increment();
            }

            Assert.AreEqual(result, _counter.Ticks);
        }

        [Test]
        public void Reset()
        {
            _counter.Increment();
            _counter.Reset();
            Assert.AreEqual(0, _counter.Ticks);
        }

    

        [Test]
        public void Clock_Initialize()
        {
            Assert.AreEqual("00:00:00", Clock.Show());
        }

       
       

        [Test]
        [TestCase("00:01:00", "00:00:59")]
        [TestCase("01:00:00", "00:59:59")]
        [TestCase("00:00:00", "23:59:59")]
        public void TestClockRollover(string real, string expected)
        {

            Clock.GetCounter(0).Set(59);
            Clock.GetCounter(1).Set(59);
            Clock.GetCounter(2).Set(23);


            Clock.Tick();


            Assert.AreEqual("00:00:00", Clock.Show());


            int hours = int.Parse(expected.Substring(0, 2));
            int minutes = int.Parse(expected.Substring(3, 2));
            int seconds = int.Parse(expected.Substring(6, 2));
            Clock.GetCounter(0).Set(seconds);
            Clock.GetCounter(1).Set(minutes);
            Clock.GetCounter(2).Set(hours);


            Clock.Tick();


            Assert.AreEqual(real, Clock.Show());
        }



    }
}
