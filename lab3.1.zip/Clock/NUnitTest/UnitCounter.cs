



namespace Clock
{
    public class Tests
    {
        private Counter _counter;

        [SetUp]
        public void Setup()
        {
            _counter = new Counter("Test counter");
        }

        [Test]
        public void TestName()
        {
            Assert.AreEqual("Test counter", _counter.Name);
        }

        [TestCase(60, 60)]
        [TestCase(100, 100)]

        [Test]
        public void Increment(int tick, int result)
        {
            int i = 0;
            while (i<tick)
            {
                _counter.Increment();
                i++;
            }
            Assert.AreEqual(result, _counter.Ticks);
        }

        [Test]
        public void Reset()
        {
            _counter.Increment();
            _counter.Reset();
            Assert.AreEqual(0, _counter.Ticks);
        }

        [Test]
        public void Tick()
        {
            Clock.Tick();
            Assert.AreEqual(1, Clock.GetCounter(0).Ticks); 
            Assert.AreEqual(0, Clock.GetCounter(1).Ticks); 
            Assert.AreEqual(0, Clock.GetCounter(2).Ticks); 
        }


    }
}
